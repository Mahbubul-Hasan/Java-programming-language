#Telephone Simulator

A Telephone Simulator which shows total calls, successful calls and failed calls between six telephones.
